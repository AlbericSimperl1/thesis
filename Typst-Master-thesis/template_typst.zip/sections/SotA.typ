= State of the Art

== What is shielding?
Electromagnetic shielding is a way towards improving electromagnetic compatability (EMC) by means of an electromagnetic shield. Using this shield it is possible to reduce the electromagnetic field intensity within a perscribed region @celozziBOEK. It's usecases range from military applications to civil interests. Although this is a broad range, every application eventually hopes to implement electric and magnetic immunity.

In military settings it can be used to guarantee communication security, thus protecting sensitive information transmitted using electromagnetic waves. Implementations within the medical sector are abundant when looking into civil applications. This ranges from the isolation of units where bio-electric signals are measured as in EEG and ECG imaging. MRI-machining induces an immense magnetic field, to ensure safety the stray field must be contained within the MRI-units.


nog iets van pacemakers
nog iets van stralignsexposure, denk dan aan de spandoeken welke politieker het minst kanker verwekt

uiteindelijk concluderen dat elke toepassing echte isolatie probeert te verwezenlijken, zowel inkomend als uitgaand.
